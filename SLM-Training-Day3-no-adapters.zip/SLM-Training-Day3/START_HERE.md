# Day 3: optimisation, from cloud to the edge

This folder holds **everything Day 3 needs**: the six notebooks, the helper files they import, the small data files, the install list and one setup script. You do **not** need the Day 1 or Day 2 folders.

## What is inside (`slm-training/`)

| Item | What it is |
|---|---|
| `day3/` | Labs 16 to 21: prompt practices, fine-tuning, real quantisation, serving many users, when the intent is wrong, the finale |
| `day3_extra/` | **four optional extra labs** (X1 to X4), for when there is spare time: advanced prompting, multi-agent with LangGraph for cost and latency, a complete TV dialogue manager, an end-to-end voice assistant. Do them **after** Labs 16 to 21 |
| `x_prompting.py`, `x_agents.py`, `x_voice.py`, `tv_domain.py`, `tv_nlu.py`, `tv_manager.py` | helpers for the extra labs |
| `data/voice/` | spoken clips for Lab 21 and extra lab X4 (so nobody needs to record anything) |
| `edge_nlu.py`, `edge_lab.py`, `edge_train.py`, `edge_gguf.py`, `edge_serve.py`, `edge_confidence.py`, `edge_voice.py` | helpers for Day 3 (plain Python: open them if you are curious) |
| `data/edge_golden.json` | the 72 test messages (the golden set) |
| `data/edge_adapter_prepared/` | a prepared Lab 17 adapter (74 MB), trained the same way. Lab 18 uses it automatically if your own Lab 17 adapter is missing |
| `slm_lab.py`, `graph_slm.py`, `graph_viz.py`, `home_domain.py`, `home_manager.py`, `lc_slm.py` | helpers from Days 1 and 2 that the notebooks import |
| `setup_day3.sh` | the one-time setup for Labs 18 and 19 (start it first) |
| `requirements.txt` | the packages to install |

## Run it on Runpod

1. Create a Pod: an NVIDIA GPU with **24 GB** (RTX 4090 is what we tested) or more, template **Runpod PyTorch 2.8.0 (CUDA 12.8.1)**, a volume of **at least 30 GB** at `/workspace`, container disk 50 GB.
2. Open Jupyter Lab and upload `SLM-Training-Day3.zip` into `/workspace`.
3. Open a terminal and run:
   ```bash
   cd /workspace
   unzip -o SLM-Training-Day3.zip
   cd SLM-Training-Day3/slm-training
   pip install --no-cache-dir -r requirements.txt
   bash setup_day3.sh
   ```
   `setup_day3.sh` runs in the background for 10 to 20 minutes. Follow it with `tail -f /workspace/day3_setup.log`; it ends with `SETUP DONE`. Do not wait for it: start Lab 16.
4. Work through `day3/lab16_prompt_engineering.ipynb` to `lab21_check_the_brief.ipynb` **in number order**. In each notebook use **Kernel, Restart Kernel and Run All Cells**.
5. Models are downloaded the first time and kept on the volume: Qwen2.5-1.5B (about 3 GB), Qwen2.5-3B in Lab 20 (about 6 GB, already there if you did Day 2), Whisper small and a small text-to-speech model in Lab 21 (about 1 GB).
6. **Stop the Pod** when you finish (Pods, the three dots, Stop). Never Terminate.

## How long things take (measured on one RTX 4090 pod; other GPUs and busy pods can be slower)

| Step | Measured |
|---|---|
| Lab 16, all cells | about 1 minute |
| Lab 17, all cells, with the training (it checks your GPU first) | about 1.5 minutes |
| Lab 18, all cells (merge, GGUF, four sizes, CPU runs, 8-bit and 4-bit) | about 8 minutes |
| Lab 19, all cells (including starting the vLLM server and the load test) | 1 to 2 minutes (the server took 33 to 93 seconds to start) |
| Lab 20, all cells | about 30 seconds |
| Lab 21, all cells | about 25 seconds |
| `setup_day3.sh` (llama.cpp, GGUF tools, vLLM) | 10 to 20 minutes, in the background |

These are run times of the cells on one RTX 4090 pod with 16 vCPUs, **after** the model files were downloaded. Downloads and a slower GPU add to them: Qwen2.5-1.5B is about 3 GB, Qwen2.5-3B about 6 GB.

## If something is slow or stuck

- Do **not** wait more than a few minutes on any cell. Interrupt the kernel (Kernel, Interrupt) and ask the trainer.
- If your Lab 17 training fails or is too slow, do not wait: go on to Lab 18, which uses the prepared adapter when yours is missing.
- A first message on a new `.gguf` file can take 10 seconds or more while the file is read from disk: this is normal, once per file.
- If a download is slow, start the next lab's setup while it runs, or ask the trainer.
- If the volume is full ("Disk quota exceeded"), delete old model folders you no longer need in `/workspace/.cache/huggingface/hub`, and always install with `--no-cache-dir`.

## The labs

| Lab | Topic | Time |
|---|---|---|
| 16 | Prompt engineering, best practices: one practice at a time, five prompts, one scoreboard | 40 min |
| 17 | Teach the model in a small memory: QLoRA fine-tune, before and after | 60 min |
| 18 | Make the model small, for real: merge, GGUF, four sizes, CPU only | 55 min |
| 19 | Many people, one device: KV cache, batching, a vLLM load test | 75 min |
| 20 | When the intent is wrong: confidence, ask back, a bigger-model fallback | 45 min |
| 21 | Check the brief, then hear it work: the scoreboard and the speech demo | 25 min |

## Optional extra labs (`day3_extra/`), in this order, only if time allows

| Lab | Topic | Time |
|---|---|---|
| X1 | Advanced prompt engineering: examples, grammar-constrained answers, voting, reasoning, injection, automatic prompt search, prompt versions | 50 min |
| X2 | Multi-agent with LangGraph, designed for cost and latency: five designs measured on the same 20 requests | 55 min |
| X3 | A complete dialogue manager for a TV with the small model: all dialogue patterns, 53 scenarios | 60 min |
| X4 | An end-to-end voice assistant: speech in, dialogue manager, speech out, noise tests, where the chain breaks | 50 min |

Run them with the same Pod as Labs 16 to 21. X1 needs the GGUF files of Lab 18. X3 trains a small TV adapter (about 2 minutes) and X4 uses it.
