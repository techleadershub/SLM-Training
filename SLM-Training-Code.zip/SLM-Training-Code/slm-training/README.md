# SLM training: labs

Jupyter notebooks for the three days. Open them in number order:

- `day1/` Labs 1 to 8: transformers, RAG, guardrails
- `day2/` Labs 9 to 15: dialogue management with LangGraph
- `day3/` Labs 16 to 21: optimisation

## Run on Runpod

1. Create a Pod: any NVIDIA GPU with 16 GB or more, template **Runpod PyTorch** (2.x), volume disk 20 GB or more at `/workspace`.
2. Open Jupyter Lab, upload this zip into `/workspace`, open a terminal and run:
   ```bash
   cd /workspace
   unzip -o SLM-Training-Code.zip
   cd SLM-Training-Code/slm-training
   pip install -r requirements.txt
   ```
   Do not reinstall PyTorch; the template already has it.
3. Open `day1/lab01_setup.ipynb` and work through the labs. In each notebook use **Kernel, Restart Kernel and Run All Cells**.
4. Stop the Pod when you finish.

Optional extra labs for more depth and more domains are in `extras/` (see `extras/README.md`); they are not part of the three days.

Files: `slm_lab.py`, `graph_slm.py`, `home_domain.py`, `home_manager.py` and `graph_viz.py` are helpers the notebooks import; `data/` holds the
(fictional) company and appliance data. Models are downloaded from Hugging Face on first use.

Optional: Lab 21 can benchmark the vLLM serving engine; its set-up commands are in the lab.
