"""Benchmark helper for Lab 21 (section 21.6b). Run it with the Python of an environment that has vLLM installed.

    /root/vllm-venv/bin/python vllm_bench.py --model Qwen/Qwen2.5-3B-Instruct --prompts prompts.json --out result.json

It answers the same prompts twice with the same engine: one request at a time, and all requests together (the engine batches
them continuously). It writes the seconds and the answers to a JSON file that the notebook reads.
"""
import argparse
import json
import time

p = argparse.ArgumentParser()
p.add_argument("--model", required=True)
p.add_argument("--prompts", required=True)
p.add_argument("--out", required=True)
p.add_argument("--mem", type=float, default=0.4, help="share of the GPU memory the engine may use")
a = p.parse_args()

prompts = json.load(open(a.prompts, encoding="utf-8"))
from vllm import LLM, SamplingParams  # noqa: E402  (imported late so --help works without vLLM)

llm = LLM(model=a.model, gpu_memory_utilization=a.mem, max_model_len=2048, dtype="bfloat16", enforce_eager=False)
params = SamplingParams(temperature=0, max_tokens=80)
llm.generate(prompts[:2], params)                         # warm-up

few = prompts[:min(16, len(prompts))]
t = time.perf_counter()
for one in few:
    llm.generate([one], params)
sequential_s = time.perf_counter() - t

t = time.perf_counter()
outs = llm.generate(prompts, params)
batched_s = time.perf_counter() - t

json.dump({"sequential_questions": len(few), "sequential_seconds": sequential_s, "batched_questions": len(prompts),
           "batched_seconds": batched_s, "answers": [o.outputs[0].text for o in outs]}, open(a.out, "w"), ensure_ascii=False)
print("done")
