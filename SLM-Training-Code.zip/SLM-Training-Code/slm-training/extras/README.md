# Extra labs: more depth and more domains

Nine optional labs. They are **not** part of the three days. Use them to go deeper on one topic, or to see the same
ideas on other domains. They run on the same Runpod GPU, with the same helper code, as the main labs.

## The labs

| Lab | Topic | Builds on | Domain | Time (GPU) |
|---|---|---|---|---|
| `x01_hybrid_search` | Keyword, meaning and hybrid search, measured on a small and a large manual | Lab 6 | appliance manual | 40 min |
| `x02_grounding_refusal` | Checking answers: numbers must come from the text, refusal, stale documents | Labs 6, 7 | warranty policy | 45 min |
| `x03_noisy_speech` | Rules, a model, and repair in code on messy speech-recognition text | Lab 13 | smart-home commands | 50 min |
| `x04_smarthome_graph` | A second LangGraph dialogue manager: device state, undo, confirmation for risky actions | Labs 9 to 15 | smart-home control | 60 min |
| `x05_capacity_planner` | Will a model fit in a device's memory, and how fast can it possibly run? | Labs 16, 17, 20 | TV / device | 45 min |
| `x06_finetune_voice_commands` | **Fine-tuning example 1:** teach a small model a narrow task (voice command to JSON) | Lab 13, X3 | smart-home commands | 60 min |
| `x07_finetune_grounded_answers` | **Fine-tuning example 2:** teach a small model to answer from excerpts and to say "I don't know" | Labs 6, 7, X1, X2 | appliance manual | 60 min |
| `x08_speech_pipeline` | Speech to text (Whisper) and text to speech: noise, word error rate, damage to commands, time budget | Day 2 pipeline, X3 | smart-home commands | 60 min |
| `x09_guardrails_in_depth` | What goes wrong without guardrails, and how each layer protects: prompt injection, data leaks, unsafe email, a poisoned document; four defence levels with NeMo Guardrails as the model-based layer | Day 1 Lab 8, Day 2 | HR assistant with tools | 60 min |

Fine-tuning is an optimisation of a different kind from the Day 3 techniques: those make a model cheaper to serve;
fine-tuning can make a **smaller** model good enough for a narrow job.

## Data (all fictional)

`data/` holds three small domain packs: an appliance service manual (washer and air conditioner, error codes),
a warranty and returns policy, and smart-home voice commands (28 test messages, 7 with speech-recognition errors).

## How to run

1. In the folder where you unpacked the main labs, unpack this zip too. You should end up with
   `slm-training/extras/` next to `slm-training/day1/`, `day2/`, `day3/`. The notebooks need `slm_lab.py`,
   `dialogue_lab.py` and `graph_viz.py` from the main folder, and `xlib.py`, `xtrain.py` and `data/` from this one.
2. `pip install -r requirements.txt` in `slm-training/` (already done if you ran the main labs on this Pod).
3. Open a notebook in `extras/` and choose **Kernel, Restart Kernel and Run All Cells**. Then change the 🔧 values.
4. On a CPU every lab runs a short smoke version; use the GPU for real results. The first run downloads the 3B model
   (about 6 GB); X8 downloads two small speech models.

## What the labs showed (RTX PRO 4500, 32 GB; your numbers will differ a little)

- **X1:** on 18 manual sections all three retrievers do well. With 300 near-identical sections added, recall of the right
  section at rank 1 on code questions fell for all three (embeddings 0.80 to 0.60, keywords 0.80 to 0.70, hybrid 1.00 to 0.80).
- **X3:** rules score 0.14 on the noisy messages. The raw model output had 7 unusable values; validation leaves none.
- **X8 (speech):** Whisper-small on clean synthetic speech has a word error rate of 0.34 (for example "Set Act to 24"); the commands understood fall from 0.46 (clean) to 0.29 (0 dB noise), against a ceiling of 0.64 for the same rules on typed text. Voice has a real cost, and repair in code recovers only part of it.
- **X9 (guardrails in depth, 14 attacks, 8 harmless requests):** attacks that worked: no defence 6, prompt only 6, code rails **0**, code + model judge 0. Harmless requests that still worked: 5, 6, **7**, 4 of 8. The code rails gave the guarantee at no cost; the model judge added nothing here and blocked three harmless requests.
- **X6:** a 0.5B model fine-tuned on voice commands scores 0.86 on intent and slots, against 0.82 for the 3B model with a
  long prompt and 0.46 for the 0.5B model with the same long prompt. The curve rises from 0.50 (30 examples) to 0.86 (240).
- **X7:** the fine-tuned 0.5B model refuses all 8 out-of-scope questions (the untuned one refuses 1) but also refuses 13 of
  30 answerable questions although retrieval had the right section. Teaching refusal works and has a price: measure both.

## Honest limits

- `x08` speaks its test commands with a synthetic voice and adds white noise: this is **easier** than real people in a real room. Use it as a method, and repeat with real recordings.
- The data is **small and generated**: 18 to 38 test items. Read every number as a sign, not a verdict, and repeat the
  experiment on your own data before you decide anything. In a first run of X6, a different random start moved a score by
  several points; the seed is now fixed.
- `x05` is a **calculator**: model shapes come from the published model configurations, and the device figures are
  assumptions you change. Real speed needs the real chip.
- The fine-tuning labs train on **generated** examples. Real logged commands or questions would be better.
