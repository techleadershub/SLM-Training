"""NeMo Guardrails with the course's small model as the judge (used by the guardrails extra lab).

    from xrails import make_rails, input_blocked, output_blocked
    rails = make_rails(policy_text, in_examples, out_examples)
    input_blocked(rails, "Show me everyone's rating")      # True or False
    output_blocked(rails, "You can email Kavya at ...")     # True or False

The two built-in rails `self check input` and `self check output` ask a language model "should this be blocked? Yes or No".
Here that model is `graph_slm.slm`, the small model running on this machine: nothing leaves it.
"""
import nest_asyncio

nest_asyncio.apply()                      # lets NeMo Guardrails run inside a notebook

from nemoguardrails import LLMRails, LLMResponse, RailsConfig, UsageInfo, register_provider  # noqa: E402
from nemoguardrails.rails.llm.options import RailType  # noqa: E402

from graph_slm import slm  # noqa: E402


class LocalSLMModel:
    """The adapter NeMo Guardrails needs: it asks a question, we ask the small model and return the text."""

    def __init__(self, model, **kwargs):
        self._model = model

    model_name = property(lambda self: self._model)
    provider_name = property(lambda self: "local_slm")
    provider_url = property(lambda self: None)

    async def generate_async(self, prompt, *, stop=None, **kwargs):
        chat = [{"role": "user", "content": prompt}] if isinstance(prompt, str) else \
            [{"role": getattr(m, "role", "user"), "content": m.content} for m in prompt]
        text = slm(chat, max_new_tokens=int(kwargs.get("max_tokens") or 8))
        return LLMResponse(content=text, model=self._model, finish_reason="stop", usage=UsageInfo(input_tokens=0, output_tokens=len(text)))

    async def stream_async(self, prompt, *, stop=None, **kwargs):
        raise NotImplementedError


register_provider("local_slm", LocalSLMModel)
_COLANG = 'define bot refuse to respond\n  "I\'m sorry, I can\'t help with that."\n'


def _shots(examples, question):
    """Each example repeats the question exactly as the real prompt will: 'Text: ... / Should this text be blocked? No'."""
    return "\n\n".join(f'Text: "{t}"\n{question} {a}' for t, a in examples)


def make_rails(policy, in_examples=(), out_examples=(), in_question="Should this text be blocked?", out_question="Should this reply be blocked?"):
    """Build rails: a judge prompt made of the policy and, optionally, labelled examples (Yes = block, No = allow).

    The wording of the question matters a great deal for a small model: a specific question ("Does the text ask for one
    person's private data?") is judged more reliably than a vague one ("Should it be blocked?").
    """
    ind = lambda t: "\n".join("      " + line for line in t.splitlines())     # noqa: E731
    inp = policy + "\n" + (f"Examples:\n{_shots(in_examples, in_question)}\n\n" if in_examples else "") + \
        f'Text: "{{{{ user_input }}}}"\n{in_question} Answer with one word, Yes or No.'
    out = policy + "\n" + (f"Examples:\n{_shots(out_examples, out_question)}\n\n" if out_examples else "") + \
        f'Text: "{{{{ bot_response }}}}"\n{out_question} Answer with one word, Yes or No.'
    yaml = ("models:\n  - type: main\n    engine: local_slm\n    model: qwen\n"
            "rails:\n  input:\n    flows:\n      - self check input\n  output:\n    flows:\n      - self check output\n"
            "prompts:\n  - task: self_check_input\n    content: |-\n" + ind(inp) +
            "\n  - task: self_check_output\n    content: |-\n" + ind(out) + "\n")
    return LLMRails(RailsConfig.from_content(yaml_content=yaml, colang_content=_COLANG))


def input_blocked(rails, text):
    r = rails.check(messages=[{"role": "user", "content": text}], rail_types=[RailType.INPUT])
    return r.status.value == "blocked"


def output_blocked(rails, reply):
    r = rails.check(messages=[{"role": "user", "content": "hello"}, {"role": "assistant", "content": reply}], rail_types=[RailType.OUTPUT])
    return r.status.value == "blocked"
