# Nova warranty and returns policy (fictional, version 2026)

## Standard warranty
Every product has a 24-month warranty on parts and a 12-month warranty on labour, counted from the purchase date on the invoice.

## Extended warranty
An extended warranty can be bought within 90 days of purchase. It adds 36 months of cover for parts and labour. The price is 12% of the purchase price.

## Returns: unopened products
An unopened product can be returned within 14 days of delivery for a full refund.

## Returns: opened products
An opened product returned within 14 days is refunded minus a 15% restocking fee. All accessories must be included.

## Faulty on arrival
Report a product that is faulty on arrival within 7 days of delivery. We replace it free of charge and collect the faulty product within 3 working days.

## What the warranty does not cover
Accidental damage, water damage, cosmetic damage and repairs by anyone who is not an authorised service engineer are not covered.

## Commercial use
If the product is used commercially, for example in a shop or an office, the parts warranty is 6 months.

## Transferring the warranty
The warranty can be transferred once, to a new owner. The new owner needs the original invoice, and the service centre must be told within 30 days of the sale.

## Refund timing
Refunds are paid within 10 working days, to the original payment method.

## Service visit charges
A home visit is free while the product is under warranty. Outside the warranty there is an inspection fee of Rs 499, which is deducted from the repair bill if you accept the repair.
