"""Small helpers shared by the extra labs (retrieval, text clean-up, validation, scoring)."""
import difflib
import json
import math
import re
from collections import Counter
from pathlib import Path

XD = Path(__file__).resolve().parent / "data"


# ------------------------------------------------------------------ documents and retrieval
def sections(name):
    """Split a markdown file with '## Title' headings into [{'title', 'text'}]."""
    out, title, buf = [], None, []
    for line in (XD / name).read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            if title:
                out.append({"title": title, "text": " ".join(buf).strip()})
            title, buf = line[3:].strip(), []
        elif title and line.strip():
            buf.append(line.strip())
    if title:
        out.append({"title": title, "text": " ".join(buf).strip()})
    return out


def jload(name):
    return json.loads((XD / name).read_text(encoding="utf-8"))


def tok(text):
    return re.findall(r"[a-z0-9]+", text.lower())


class BM25:
    """Keyword ranking (the idea behind classic search engines). Rare words count more."""

    def __init__(self, docs, k1=1.5, b=0.75):
        self.docs = [tok(d) for d in docs]
        self.k1, self.b = k1, b
        self.avg = sum(len(d) for d in self.docs) / len(self.docs)
        df = Counter(w for d in self.docs for w in set(d))
        n = len(self.docs)
        self.idf = {w: math.log(1 + (n - c + 0.5) / (c + 0.5)) for w, c in df.items()}

    def scores(self, query):
        q = tok(query)
        out = []
        for d in self.docs:
            tf = Counter(d)
            s = 0.0
            for w in q:
                if w in tf:
                    s += self.idf[w] * tf[w] * (self.k1 + 1) / (tf[w] + self.k1 * (1 - self.b + self.b * len(d) / self.avg))
            out.append(s)
        return out

    def rank(self, query):
        sc = self.scores(query)
        return sorted(range(len(sc)), key=lambda i: -sc[i])


def rrf(rank_lists, k=60):
    """Reciprocal rank fusion: combine several rankings without having to compare their scores."""
    score = Counter()
    for ranking in rank_lists:
        for pos, idx in enumerate(ranking):
            score[idx] += 1.0 / (k + pos + 1)
    return [i for i, _ in score.most_common()]


def numbers(text):
    return re.findall(r"\d+(?:\.\d+)?", text.replace(",", ""))


# ------------------------------------------------------------------ cleaning noisy speech text
_UNITS = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
          "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
          "seventeen": 17, "eighteen": 18, "nineteen": 19}
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}


def words_to_digits(text):
    """'twenty four' -> '24', 'thirty' -> '30'."""
    words, out, i = text.split(), [], 0
    while i < len(words):
        w = words[i].lower().strip(",.")
        if w in _TENS:
            val = _TENS[w]
            if i + 1 < len(words) and words[i + 1].lower().strip(",.") in _UNITS and 0 < _UNITS[words[i + 1].lower().strip(",.")] < 10:
                val += _UNITS[words[i + 1].lower().strip(",.")]
                i += 1
            out.append(str(val))
        elif w in _UNITS:
            out.append(str(_UNITS[w]))
        else:
            out.append(words[i])
        i += 1
    return " ".join(out)


def fix_rooms(text, rooms, cutoff=0.8):
    """Repair room names that speech recognition split or misspelled ('livin room', 'bed room')."""
    words = text.split()
    for n in (2, 1):
        i = 0
        while i + n <= len(words):
            cand = " ".join(words[i:i + n]).lower().strip(",.")
            best = difflib.get_close_matches(cand, rooms, n=1, cutoff=cutoff)
            if not best:
                best = difflib.get_close_matches(cand.replace(" ", ""), [r.replace(" ", "") for r in rooms], n=1, cutoff=cutoff)
                best = [r for r in rooms if r.replace(" ", "") == best[0]] if best else []
            if best:
                words[i:i + n] = [best[0]]
            i += 1
    return " ".join(words)


def clean_speech(text, rooms):
    text = re.sub(r"\ba c\b", "ac", text.lower())
    return fix_rooms(words_to_digits(text), rooms)


# ------------------------------------------------------------------ smart-home understanding
V = None


def vocab():
    global V
    if V is None:
        V = jload("smarthome_vocab.json")
    return V


def snap(value, options, cutoff=0.75):
    """Return the closest allowed value, or None when nothing is close enough."""
    if value is None:
        return None
    best = difflib.get_close_matches(str(value).lower(), [str(o).lower() for o in options], n=1, cutoff=cutoff)
    return best[0] if best else None


def validate(intent, slots):
    """Check a model's output against the allowed values. Returns (clean_slots, dropped_keys)."""
    v = vocab()
    spec = v["intents"].get(intent) if isinstance(intent, str) else None
    if spec is None or not isinstance(slots, (dict, type(None))):
        return {}, ["intent"]
    clean, dropped = {}, []
    for k, val in (slots or {}).items():
        if k not in spec["slots"]:
            dropped.append(k)
            continue
        if k == "room":
            s = snap(val, v["rooms"])
        elif k == "scene":
            s = snap(val, v["scenes"])
        elif k == "device":
            s = snap(val, spec["device"])
        elif k == "state":
            s = snap(val, spec["state"], 0.9)
        elif k in ("temp", "brightness"):
            lo, hi = (spec["temp"] if k == "temp" else v["brightness"])
            try:
                n = int(float(val))
                s = n if lo <= n <= hi else None
            except (TypeError, ValueError):
                s = None
        else:
            s = None
        if s is None:
            dropped.append(k)
        else:
            clean[k] = s
    return clean, dropped


def json_from(text):
    """First JSON object in a model reply, or None."""
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


def score_nlu(preds, gold):
    """preds: list of (intent, slots). Returns intent accuracy and exact-slot accuracy."""
    n = len(gold)
    intent_ok = sum(p[0] == g["intent"] for p, g in zip(preds, gold))
    slots_ok = sum(p[0] == g["intent"] and p[1] == g["slots"] for p, g in zip(preds, gold))
    return intent_ok / n, slots_ok / n


# ------------------------------------------------------------------ rules baseline (also used by X3's idea, kept here for X8)
def rules_nlu(text):
    """Keyword rules for the smart-home commands. Returns (intent, validated slots)."""
    v = vocab()
    t = text.lower()
    slots, intent = {}, "unsupported"
    if re.search(r"\b(light|lights|lamp)\b", t):
        intent = "set_light"
    elif re.search(r"\b(ac|air conditioner)\b", t):
        intent = "set_ac"
    elif re.search(r"\b(blind|blinds)\b", t):
        intent = "set_blinds"
    for sc in v["scenes"]:
        if sc in t:
            intent, slots["scene"] = "run_scene", sc
    if intent in ("set_light", "set_ac") and re.search(r"\b(is the|what is)\b", t):
        intent = "query_status"
        slots["device"] = "light" if "light" in t else "ac"
    for r in v["rooms"]:
        if r in t:
            slots["room"] = r
    if intent in ("set_light", "set_ac"):
        if re.search(r"\boff\b", t):
            slots["state"] = "off"
        elif re.search(r"\bon\b", t):
            slots["state"] = "on"
    m = re.search(r"(\d+)\s*(percent|%)", t)
    if intent == "set_light" and m:
        slots["brightness"] = int(m.group(1))
    m = re.search(r"\b(\d+)\b", t)
    if intent == "set_ac" and m and "percent" not in t:
        slots["temp"] = int(m.group(1))
    if intent == "set_blinds":
        slots["state"] = "open" if re.search(r"\bopen\b", t) else "closed" if re.search(r"\b(close|shut)\b", t) else None
        slots = {k: x for k, x in slots.items() if x}
    return intent, validate(intent, slots)[0]


# ------------------------------------------------------------------ speech helpers
_ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen",
         "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
_TENS_W = {2: "twenty", 3: "thirty", 4: "forty", 5: "fifty", 6: "sixty", 7: "seventy", 8: "eighty", 9: "ninety"}


def digits_to_words(text):
    """'set ac to 24' -> 'set ac to twenty four' (a text-to-speech model reads letters, not digits)."""
    def conv(m):
        n = int(m.group(0))
        if n < 20:
            return _ONES[n]
        if n < 100:
            return _TENS_W[n // 10] + ("" if n % 10 == 0 else " " + _ONES[n % 10])
        return " ".join(_ONES[int(c)] for c in m.group(0))
    return re.sub(r"\d+", conv, text)


def spell(text):
    t = digits_to_words(text.lower()).replace("%", " percent")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z ]", " ", t)).strip()


def norm_words(text):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", text.lower())).strip().split()


def wer(ref, hyp):
    """Word error rate: (substitutions + deletions + insertions) / words in the reference."""
    r, h = norm_words(ref), norm_words(hyp)
    d = list(range(len(h) + 1))
    for i in range(1, len(r) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(h) + 1):
            cur = d[j]
            d[j] = min(d[j] + 1, d[j - 1] + 1, prev + (r[i - 1] != h[j - 1]))
            prev = cur
    return d[len(h)] / max(len(r), 1)
