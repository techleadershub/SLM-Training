"""LoRA fine-tuning helper for the two fine-tuning labs (X6 and X7). Needs slm_lab.py from the course folder."""
import torch
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from transformers import Trainer, TrainingArguments, set_seed

from slm_lab import FAST, OUT, count_params, device, encode_chat


def lora_finetune(tok, model, examples, epochs=3, lr=2e-4, r=16, batch_size=8, max_len=512):
    """Fine-tune `model` with LoRA on `examples` (each one a list of chat messages ending with the assistant's reply).

    Returns (peft_model, trainer, result, trainable_percent). The loss is computed on the assistant's reply only.
    """
    set_seed(42)                      # the LoRA matrices start from random numbers: fix them, so runs are repeatable
    tok.padding_side = "right"
    cfg = LoraConfig(r=r, lora_alpha=2 * r, lora_dropout=0.05, task_type="CAUSAL_LM",
                     target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"])
    model = get_peft_model(model, cfg)
    trainable, total = count_params(model)
    ds = Dataset.from_list([encode_chat(tok, m, max_len) for m in examples])

    def collate(batch):
        n = max(len(b["input_ids"]) for b in batch)
        pad = tok.pad_token_id
        return {
            "input_ids": torch.tensor([b["input_ids"] + [pad] * (n - len(b["input_ids"])) for b in batch]),
            "attention_mask": torch.tensor([b["attention_mask"] + [0] * (n - len(b["attention_mask"])) for b in batch]),
            "labels": torch.tensor([b["labels"] + [-100] * (n - len(b["labels"])) for b in batch]),
        }

    on_gpu = device() == "cuda"
    args = TrainingArguments(
        output_dir=str(OUT / "x_checkpoints"), num_train_epochs=epochs, per_device_train_batch_size=batch_size,
        learning_rate=lr, lr_scheduler_type="cosine", warmup_steps=5, weight_decay=0.0, logging_steps=10,
        save_strategy="no", report_to="none", bf16=on_gpu and torch.cuda.is_bf16_supported(),
        fp16=on_gpu and not torch.cuda.is_bf16_supported(), max_steps=6 if FAST else -1,
        remove_unused_columns=False, seed=42)
    trainer = Trainer(model=model, args=args, train_dataset=ds, data_collator=collate)
    result = trainer.train()
    model.eval()
    tok.padding_side = "left"
    return model, trainer, result, 100 * trainable / total
