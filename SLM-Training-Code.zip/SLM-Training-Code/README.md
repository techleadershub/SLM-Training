# Code for the 3-day SLM training

Everything is in `slm-training/`. Start with `slm-training/README.md`.
