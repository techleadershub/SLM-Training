# Day 2: from LLM to working agent

This folder holds **everything Day 2 needs**: the seven notebooks, the helper files they import, the small data files and the install list.
You do **not** need the Day 1 or Day 3 folders.

## What is inside (`slm-training/`)

| Item | What it is |
|---|---|
| `day2/` | Labs 9 to 15: tools and ReAct, LangGraph basics, routing and fan-out, memory and human in the loop, guardrails with NeMo Guardrails, evals with DeepEval, the dialogue manager |
| `lc_slm.py` | the small language model as a normal LangChain chat model |
| `agent_rails.py` | NVIDIA NeMo Guardrails helper (Lab 13) |
| `slm_lab.py`, `graph_slm.py`, `graph_viz.py`, `home_domain.py`, `home_manager.py` | helpers the notebooks import |
| `data/` | the (fictional) company and appliance data |
| `requirements.txt` | the packages to install |

## Run it on Runpod

1. Create a Pod: any NVIDIA GPU with 16 GB or more, template **Runpod PyTorch 2.8.0 (CUDA 12.8.1)**, a **network volume** of 20 GB or more mounted at `/workspace`.
2. Open Jupyter Lab and upload `SLM-Training-Day2.zip` into `/workspace`.
3. Open a terminal and run:
   ```bash
   cd /workspace
   unzip -o SLM-Training-Day2.zip
   cd SLM-Training-Day2/slm-training
   pip install -r requirements.txt
   ```
   This takes 3 to 6 minutes. Do not reinstall PyTorch: the template has it.
4. Open `day2/lab09_tools_and_react.ipynb` and work through the labs **in number order**. In each notebook use **Kernel, Restart Kernel and Run All Cells**.
5. The first time a notebook loads the model (Qwen2.5-3B, about 6 GB) it is downloaded and kept on the volume. Later labs reuse it.
6. Lab 14 installs DeepEval by itself (about a minute). pip may print a note about a version conflict with `click`: it is harmless for these labs.
7. **Stop the Pod** when you finish (Pods, the three dots, Stop). Never Terminate.

After you stop and start a Pod, the installed packages are erased: run `pip install -r requirements.txt` again. Your files and the downloaded model stay on the volume.

## The labs

| Lab | Topic | Time |
|---|---|---|
| 9 | Tools and ReAct: tool calls by hand, then `create_agent`, measured on ten requests | 60 min |
| 10 | LangGraph basics: state, nodes, normal and conditional edges, with the small model from the first line | 40 min |
| 11 | Routing, retry loops, reducers, Command, the recursion limit, fan-out and fan-in | 50 min |
| 12 | Memory and human in the loop: checkpointer, summary, store (semantic, episodic, procedural), interrupt, time travel | 55 min |
| 13 | Guardrails for an agent with NeMo Guardrails, validated tools, limits and human approval | 55 min |
| 14 | Evals with DeepEval: a golden dataset, metrics, a judge, a regression | 40 min |
| 15 | The dialogue manager: the full assistant | 50 min |
